#!/bin/sh

VERSION='5.5.0'
SCRIPT_PATH=$(dirname "$0")
M2_PATH="${HOME}/.m2/repository"
MISNAP_PATH='com/miteksystems/misnap'

usage() {
  echo "Usage: $0 [-h|--help] [-i|--install] [-c|--clean-install] [-a|--uninstall-all] [-v <string>] [-p <string>]"
  echo "-h: Displays the help message."
  echo "-i: Installs this version of MiSnap."
  echo "-c: Removes all other versions of MiSnap and installs this version."
  echo "-a: Removes all versions of MiSnap."
  echo "-v: Removes the specific version of MiSnap."
  echo "-p: Overrides the default maven local path."
  exit 1
}

uninstall_all() {
  ROOT_PATH="${M2_PATH}/${MISNAP_PATH}/"
  if [ -d "$ROOT_PATH" ]; then
    rm -r "${ROOT_PATH}"
  fi
}

uninstall_version() {
  if [ -z "${VERSION}" ]; then
    echo "Required variable VERSION not set."
    exit 1
  fi
  for DIR in "${SCRIPT_PATH}"/*; do
    if [ -d "${DIR}" ]; then
      DIR_NAME=$(basename "${DIR}")
      OUTPUT_PATH="${M2_PATH}/${MISNAP_PATH}/${DIR_NAME}/${VERSION}/"
      if [ -d "$OUTPUT_PATH" ]; then
        rm -r "${OUTPUT_PATH}"
      fi
    fi
  done
}

deploy_unix() {
  for DIR in "${SCRIPT_PATH}"/*; do
    if [ -d "${DIR}" ]; then
      DIR_NAME=$(basename "${DIR}")
      OUTPUT_PATH="${M2_PATH}/${MISNAP_PATH}/${DIR_NAME}/${VERSION}/"

      mkdir -p "${OUTPUT_PATH}"
      cp -r "${DIR}/." "${OUTPUT_PATH}"
    fi
  done
}

if [[ $(uname) != *"Linux"* ]] && [[ $(uname) != *"Darwin"* ]]; then
  echo "This OS is not supported by this script. If you're running on Windows, please run .bat file instead."
  exit 1
fi

for arg in "$@"; do
  shift
  case "$arg" in
    "--help")            set -- "$@" "-h" ;;
    "--install")         set -- "$@" "-i" ;;
    "--clean-install")   set -- "$@" "-c" ;;
    "--uninstall-all")   set -- "$@" "-a" ;;
    "--"*)               set -- "$@" "-h" ;;
    *)                   set -- "$@" "$arg"
  esac
done
OPTIND=1

optstring="hicav:p:"
while getopts "$optstring" options; do
  case $options in
    h)
      usage;;
    p)
      M2_PATH=${OPTARG};;
  esac
done
OPTIND=1

while getopts "$optstring" options; do
  case $options in
    i)
      deploy_unix
      echo "MiSnap ${VERSION} has been installed."
      exit 0
      ;;
    c)
      uninstall_all
      deploy_unix
      echo "MiSnap ${VERSION} has been cleanly installed."
      exit 0
      ;;
    a)
      uninstall_all
      echo "All versions of MiSnap have been uninstalled."
      exit 0
      ;;
    v)
      VERSION=${OPTARG}
      uninstall_version
      echo "MiSnap ${VERSION} has been uninstalled."
      exit 0
      ;;
  esac
done
shift $((OPTIND-1))

usage